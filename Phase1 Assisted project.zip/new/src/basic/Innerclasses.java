package basic;

	//Outer Class
	class OuterClass {
	    //Private variable
	    private String outerVariable = "This is a private variable of the outer class";

	    //Inner class
	    public class InnerClass {
	        //Method to modify the private variable of the outer class
	        public void modifyOuterVariable() {
	            outerVariable = "The private variable of the outer class has been modified";
	        }
	    }

	    //Method to retrieve the private variable
	    public String getOuterVariable() {
	        return outerVariable;
	    }
	}

	//Main class
	public class Innerclasses {
	    public static void main(String[] args) {
	        //Creating an instance of the outer class
	        OuterClass outer = new OuterClass();

	        //Creating an instance of the inner class
	        OuterClass.InnerClass inner = outer.new InnerClass();

	        //Printing the private variable before modification
	        System.out.println("Private variable before modification: " + outer.getOuterVariable());

	        //Modifying the private variable using the inner class method
	        inner.modifyOuterVariable();

	        //Printing the private variable after modification
	        System.out.println("Private variable after modification: " + outer.getOuterVariable());
	    }
	}
	


	
	

















