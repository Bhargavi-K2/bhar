package basic;

public class Accessmodifier {

	    public int publicVariable = 10;
	    private int privateVariable = 20;
	    protected int protectedVariable = 30;
	    int defaultVariable = 40;

	    public void publicMethod() {
	        System.out.println("Public Method: Accessing publicVariable " + publicVariable);
	        System.out.println("Public Method: Accessing privateVariable " + privateVariable);
	        System.out.println("Public Method: Accessing protectedVariable " + protectedVariable);
	        System.out.println("Public Method: Accessing defaultVariable " + defaultVariable);
	    }

	    private void privateMethod() {
	        System.out.println("Private Method: Accessing publicVariable " + publicVariable);
	        System.out.println("Private Method: Accessing privateVariable " + privateVariable);
	        System.out.println("Private Method: Accessing protectedVariable " + protectedVariable);
	        System.out.println("Private Method: Accessing defaultVariable " + defaultVariable);
	    }

	    protected void protectedMethod() {
	        System.out.println("Protected Method: Accessing publicVariable " + publicVariable);
	        System.out.println("Protected Method: Accessing privateVariable " + privateVariable);
	        System.out.println("Protected Method: Accessing protectedVariable " + protectedVariable);
	        System.out.println("Protected Method: Accessing defaultVariable " + defaultVariable);
	    }

	    void defaultMethod() {
	        System.out.println("Default Method: Accessing publicVariable " + publicVariable);
	        System.out.println("Default Method: Accessing privateVariable " + privateVariable);
	        System.out.println("Default Method: Accessing protectedVariable " + protectedVariable);
	        System.out.println("Default Method: Accessing defaultVariable " + defaultVariable);
	    }

	    public static void main (String[] args) {
	        Accessmodifier accessmodifier = new Accessmodifier ();
	        accessmodifier.publicMethod();
	        accessmodifier .privateMethod();
	        accessmodifier.protectedMethod();
	        accessmodifier.defaultMethod();
	    }
	}


	