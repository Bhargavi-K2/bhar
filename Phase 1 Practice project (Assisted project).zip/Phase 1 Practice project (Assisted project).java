package project;

public class typecasting {
	
	public static void main(String[] args) {
		
	System.out.println("Implicit type casting");
	
	char a='A';
	int b=a;
	float c=a;
	long d=a;
	double e=a;
	
	System.out.println("Value of a: "+a);
	
	System.out.println("Value of b: "+b);

	System.out.println("Value of c: "+c);
	
	System.out.println("Value of d: "+d);
	
	System.out.println("Value of e: "+e);
	
    System.out.println("\n");
    
	System.out.println("Explicit type casting");
	
	double x=35.5;
	int y=(int)x;
	
	System.out.println("Value of x: "+x);
	
	System.out.println("Value of y: " +y);
	

}
	
}

