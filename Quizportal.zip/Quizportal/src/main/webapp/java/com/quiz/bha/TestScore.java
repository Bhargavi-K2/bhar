package com.quiz.bha;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
@Entity
public class TestScore {
@Id
@GeneratedValue(strategy=GenerationType.AUTO)
private int id;
private String name;
private int Score ;
private String dbname;
public String getName() {
return name;
}
public void setName(String name) {
this.name = name;
}
public int getScore() {
return Score;
}
public void setScore(int score) {
Score = score;
}
public String getDbname() {
return dbname;
}
public void setDbname(String dbname) {
this.dbname = dbname;
}
}

