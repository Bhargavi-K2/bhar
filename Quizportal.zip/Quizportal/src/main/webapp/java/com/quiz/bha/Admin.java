package com.quiz.bha;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
@Entity
public class Admin {
 
@Id
private String useremail;
private String userpass;
public String getUseremail() {
return useremail;
}
public String getUserpass() {
return userpass;
}
}