package com.ecommerce.service;

import java.util.List;

import org.apache.el.stream.Optional;
import org.springframework.beans.factory.annotation.Autowired;

import com.ecommerce.entity.Quiz;
import com.ecommerce.repository.QuizRepository;

public class QuizService {
	 @Autowired
	    private QuizRepository quizRepository;
	 public Quiz createQuiz(Quiz quiz) {
	        return quizRepository.save(quiz);
	    }
	 public List<Quiz> getAllQuizzes() {
	        return quizRepository.findAll();
	    }

	    public Quiz updateQuiz(Quiz quiz) {
	        Optional<Quiz> existingQuiz = quizRepository.findById(quiz.getId());
	        if (existingQuiz.isPresent()) {
	            return quizRepository.save(quiz);
	        } else {
	            throw new RuntimeException("Quiz not found");
	        }
	    }

	    public void deleteQuizById(Long id) {
	        quizRepository.deleteById(id);
	    }
	}
