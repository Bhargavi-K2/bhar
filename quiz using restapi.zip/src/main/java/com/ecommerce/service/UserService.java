package com.ecommerce.service;

import org.springframework.beans.factory.annotation.Autowired;

import com.ecommerce.entity.User;
import com.ecommerce.repository.UserRepository;

public class UserService {
	 @Autowired
	    private UserRepository userRepository;
	 public User registerUser(User user) {
		    BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
		    String encodedPassword = passwordEncoder.encode(user.getPassword());
		    user.setPassword(encodedPassword);
		    return userRepository.save(user);
		}
	 public CustomUserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
		    User user = userRepository.findByEmail(email);
		    if (user == null) {
		        throw new UsernameNotFoundException("User not found with email: " + email);
		    }
	 }
	}


