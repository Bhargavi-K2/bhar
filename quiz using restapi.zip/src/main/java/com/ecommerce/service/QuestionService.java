package com.ecommerce.service;

import org.apache.el.stream.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.crossstore.ChangeSetPersister.NotFoundException;

import com.ecommerce.entity.Question;
import com.ecommerce.repository.QuestionRepository;

public class QuestionService {
	 @Autowired
	    private QuestionRepository questionRepository;
	 public Question addQuestion(Question question) {
		    return questionRepository.save(question);
		}
	 public Question getQuestionById(Long id) {
		    java.util.Optional<Question> optionalQuestion = questionRepository.findById(id);
		    if (optionalQuestion.isPresent()) {
		        return optionalQuestion.get();
		    } else {
		        throw new NotFoundException();
		    }
		}
	}


