package com.ecommerce.entity;

import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

public class UserResponse {
	 @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long id;
	    private String username;
	    private String answerA;
	    private String answerB;
	    private String answerC;
	    private String answerD;
	    private Integer score;
	    @ManyToOne
	    @JoinColumn(name = "quiz_id")
	    private Quiz quiz;
		public Long getId() {
			return id;
		}
		public void setId(Long id) {
			this.id = id;
		}
		public String getUsername() {
			return username;
		}
		public void setUsername(String username) {
			this.username = username;
		}
		public String getAnswerA() {
			return answerA;
		}
		public void setAnswerA(String answerA) {
			this.answerA = answerA;
		}
		public String getAnswerB() {
			return answerB;
		}
		public void setAnswerB(String answerB) {
			this.answerB = answerB;
		}
		public String getAnswerC() {
			return answerC;
		}
		public void setAnswerC(String answerC) {
			this.answerC = answerC;
		}
		public String getAnswerD() {
			return answerD;
		}
		public void setAnswerD(String answerD) {
			this.answerD = answerD;
		}
		public Integer getScore() {
			return score;
		}
		public void setScore(Integer score) {
			this.score = score;
		}
		public Quiz getQuiz() {
			return quiz;
		}
		public void setQuiz(Quiz quiz) {
			this.quiz = quiz;
		}
	    

}
